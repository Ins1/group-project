# SchoolManagementSystem
1. this is mainly php project including javascript, css & ajax using xampp v3.2.1
2. keep all files in a folder & named it "schoolmanagemenetsystem".
3. enjoy coding.
