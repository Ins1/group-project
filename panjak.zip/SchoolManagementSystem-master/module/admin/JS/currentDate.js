function date(){
  var date = new Date();
  document.getElementById('date').innerHTML = date;
}
